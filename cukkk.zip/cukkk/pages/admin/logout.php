<?php

session_destroy();
?>