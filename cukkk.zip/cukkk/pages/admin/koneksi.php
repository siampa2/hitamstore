<?php
$koneksi=new mysqli("localhost","root","","database_toko");

?>