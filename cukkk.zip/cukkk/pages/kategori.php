<?php
session_start();
include "koneksi.php";
?>

<!DOCTYPE html>
<html>
<head>
    <title>Daftar Kategori Sepatu</title>
</head>
<body>
    <h1>Kategori Sepatu</h1>
    <ul>
        <?php
        if ($result->num_rows > 0) {
            // Output data setiap baris
            while($row = $result->fetch_assoc()) {
                echo "<li>" . $row["name"] . "</li>";
            }
        } else {
            echo "0 hasil";
        }
        $conn->close();
        ?>
    </ul>
</body>
</html>

